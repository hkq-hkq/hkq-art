fn main() {
    println!("hello world {}", hkq_art::add_one(5));
}
